<template>
    <div class="insertForm">
        <input type="text" v-model='filmSearch'>
        {{filmSearch}}
        <button v-on:click="SearchFilm">search</button>
    </div>
</template>
<script lang="ts">

import { Component, Vue, Prop } from 'vue-property-decorator';

@Component
export default class InsertForm extends Vue{

    public filmSearch: string='';

    public SearchFilm(){
        let endPoint: string='http://www.omdbapi.com/?t='+this.filmSearch;
        this.axios.get(endPoint)
        .then(response => (console.log(response)))
    }
}
</script>
<style lang="scss" scoped>
</style>
